; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun m () Int)
(declare-fun lam () Int)
(declare-fun price () Int)
(assert
 (>= n 0))
(assert
 (<= n m))
(assert
 (> lam 0))
(assert
 (> price 0))
(assert
 (let (($x35 (<= (div (* lam n) price) (div (* lam m) price))))
 (not $x35)))
(check-sat)
