; benchmark generated from python API
(set-info :status unknown)
(declare-fun lo () Int)
(declare-fun hi () Int)
(assert
 (>= lo 0))
(assert
 (< (+ lo 1) hi))
(assert
 (let ((?x29 (div (+ (- hi lo) 1) 2)))
 (let (($x110 (and (< lo (+ lo (div (- hi lo) 2))) (< (+ lo (div (- hi lo) 2)) hi) (<= (- (+ lo (div (- hi lo) 2)) lo) ?x29) (<= (- hi (+ lo (div (- hi lo) 2))) ?x29))))
 (not $x110))))
(check-sat)
