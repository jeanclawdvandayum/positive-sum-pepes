; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun c () Int)
(declare-fun d () Int)
(declare-fun t () Int)
(assert
 (>= a 0))
(assert
 (<= a b))
(assert
 (<= b c))
(assert
 (> d 0))
(assert
 (>= t 0))
(assert
 (<= t d))
(assert
 (let (($x167 (<= (+ a (div (* (- b a) t) d)) (+ b (div (* (- c b) t) d)))))
 (not $x167)))
(check-sat)
