; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun q () Int)
(declare-fun lam () Int)
(declare-fun price () Int)
(assert
 (>= n 0))
(assert
 (>= q 0))
(assert
 (> lam 0))
(assert
 (> price 0))
(assert
 (let (($x192 (= (>= (div (* lam n) price) q) (>= n (div (- (+ (* q price) lam) 1) lam)))))
 (not $x192)))
(check-sat)
