; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun c () Int)
(declare-fun e () Int)
(declare-fun d () Int)
(declare-fun t () Int)
(declare-fun u () Int)
(assert
 (>= a 0))
(assert
 (<= a b))
(assert
 (>= c 0))
(assert
 (<= c e))
(assert
 (<= a c))
(assert
 (<= b e))
(assert
 (> d 0))
(assert
 (>= t 0))
(assert
 (<= t u))
(assert
 (<= u d))
(assert
 (let (($x31 (<= (+ a (div (* (- b a) t) d)) (+ c (div (* (- e c) u) d)))))
 (not $x31)))
(check-sat)
