; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(assert
 (>= a 0))
(assert
 (<= a b))
(assert
 (> d 0))
(assert
 (let (($x132 (and (= (+ a (div (* (- b a) 0) d)) a) (= (+ a (div (* (- b a) d) d)) b))))
 (not $x132)))
(check-sat)
