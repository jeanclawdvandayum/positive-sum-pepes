; benchmark generated from python API
(set-info :status unknown)
(declare-fun pot () Int)
(assert
 (>= pot 0))
(assert
 (< pot 115792089237316195423570985008687907853269984665640564039457584007913129639935))
(assert
 (let (($x212 (= pot 0)))
 (let ((?x98 (ite $x212 1 (+ (div pot 10000) (ite (= (mod pot 10000) 0) 0 1)))))
 (let ((?x46 (+ (div (+ pot 1) 10000) (ite (= (mod (+ pot 1) 10000) 0) 0 1))))
 (let ((?x124 (ite (= (+ pot 1) 0) 1 ?x46)))
 (let (($x137 (and (<= ?x98 ?x124) (<= ?x124 (+ ?x98 1)))))
 (not $x137)))))))
(check-sat)
