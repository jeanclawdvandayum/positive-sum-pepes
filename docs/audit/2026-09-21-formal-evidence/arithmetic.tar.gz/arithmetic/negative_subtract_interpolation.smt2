; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun t () Int)
(declare-fun u () Int)
(assert
 (>= a 0))
(assert
 (< a b))
(assert
 (> d 0))
(assert
 (>= t 0))
(assert
 (< t u))
(assert
 (<= u d))
(assert
 (let (($x17 (<= (- a (div (* (- b a) t) d)) (- a (div (* (- b a) u) d)))))
 (not $x17)))
(check-sat)
