; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun t () Int)
(assert
 (>= a 0))
(assert
 (<= a b))
(assert
 (> d 0))
(assert
 (>= t 0))
(assert
 (<= t d))
(assert
 (let (($x191 (and (<= a (+ a (div (* (- b a) t) d))) (<= (+ a (div (* (- b a) t) d)) b))))
 (not $x191)))
(check-sat)
