; benchmark generated from python API
(set-info :status unknown)
(declare-fun shares () Int)
(declare-fun supply () Int)
(declare-fun deposit () Int)
(assert
 (> shares 0))
(assert
 (>= supply 0))
(assert
 (>= deposit 0))
(assert
 (<= deposit shares))
(assert
 (let ((?x215 (* supply deposit)))
 (let ((?x236 (div ?x215 shares)))
 (let (($x142 (<= (+ ?x236 (div (* supply (- shares deposit)) shares)) supply)))
 (not $x142)))))
(check-sat)
