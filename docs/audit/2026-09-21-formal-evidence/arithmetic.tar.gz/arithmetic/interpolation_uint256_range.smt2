; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun t () Int)
(assert
 (>= a 0))
(assert
 (<= a b))
(assert
 (<= b 115792089237316195423570985008687907853269984665640564039457584007913129639935))
(assert
 (> d 0))
(assert
 (>= t 0))
(assert
 (<= t d))
(assert
 (let (($x189 (and (>= (+ a (div (* (- b a) t) d)) 0) (<= (+ a (div (* (- b a) t) d)) 115792089237316195423570985008687907853269984665640564039457584007913129639935))))
 (not $x189)))
(check-sat)
