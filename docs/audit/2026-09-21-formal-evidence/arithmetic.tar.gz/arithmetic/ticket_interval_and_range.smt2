; benchmark generated from python API
(set-info :status unknown)
(declare-fun pot () Int)
(assert
 (>= pot 0))
(assert
 (<= pot 115792089237316195423570985008687907853269984665640564039457584007913129639935))
(assert
 (let (($x212 (= pot 0)))
 (let ((?x98 (ite $x212 1 (+ (div pot 10000) (ite (= (mod pot 10000) 0) 0 1)))))
 (let ((?x48 (* (- ?x98 1) 10000)))
 (let (($x26 (ite $x212 (= ?x98 1) (and (< ?x48 pot) (<= (- pot ?x48) 10000)))))
 (let (($x89 (and (>= ?x98 1) (<= ?x98 (+ (div 115792089237316195423570985008687907853269984665640564039457584007913129639935 10000) 1)) $x26)))
 (not $x89)))))))
(check-sat)
