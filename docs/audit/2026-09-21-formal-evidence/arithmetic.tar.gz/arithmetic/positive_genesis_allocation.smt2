; benchmark generated from python API
(set-info :status unknown)
(declare-fun deposit () Int)
(declare-fun shares () Int)
(declare-fun supply () Int)
(assert
 (>= deposit 1))
(assert
 (<= deposit shares))
(assert
 (<= shares supply))
(assert
 (let (($x234 (and (>= (div (* supply deposit) shares) deposit) (<= (div (* supply deposit) shares) supply))))
 (not $x234)))
(check-sat)
